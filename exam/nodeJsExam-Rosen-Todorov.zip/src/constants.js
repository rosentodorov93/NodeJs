const constants = {
    PORT: 3000,
    SECRET: '74935bc4-6cb7-11ee-b962-0242ac120002',
    CONNECTION_STRING: "mongodb://127.0.0.1:27017/electronicsDb"
}

module.exports = constants